﻿namespace WindowsFormsApplication1
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.btnPd = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnCd = new System.Windows.Forms.Button();
            this.btnDd = new System.Windows.Forms.Button();
            this.btnVd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPd
            // 
            this.btnPd.BackColor = System.Drawing.Color.Black;
            this.btnPd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPd.ForeColor = System.Drawing.Color.White;
            this.btnPd.Location = new System.Drawing.Point(374, 290);
            this.btnPd.Name = "btnPd";
            this.btnPd.Size = new System.Drawing.Size(261, 132);
            this.btnPd.TabIndex = 4;
            this.btnPd.Text = "Package details";
            this.btnPd.UseVisualStyleBackColor = false;
            this.btnPd.Click += new System.EventHandler(this.btnPd_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Stencil Std", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 53);
            this.label2.TabIndex = 6;
            this.label2.Text = "Home";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.DimGray;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(32, 458);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(154, 62);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnCd
            // 
            this.btnCd.BackColor = System.Drawing.Color.Black;
            this.btnCd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCd.ForeColor = System.Drawing.Color.White;
            this.btnCd.Location = new System.Drawing.Point(32, 290);
            this.btnCd.Name = "btnCd";
            this.btnCd.Size = new System.Drawing.Size(261, 132);
            this.btnCd.TabIndex = 3;
            this.btnCd.Text = "Customer details";
            this.btnCd.UseVisualStyleBackColor = false;
            this.btnCd.Click += new System.EventHandler(this.btnCd_Click);
            // 
            // btnDd
            // 
            this.btnDd.BackColor = System.Drawing.Color.Black;
            this.btnDd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDd.ForeColor = System.Drawing.Color.White;
            this.btnDd.Location = new System.Drawing.Point(374, 123);
            this.btnDd.Name = "btnDd";
            this.btnDd.Size = new System.Drawing.Size(261, 139);
            this.btnDd.TabIndex = 2;
            this.btnDd.Text = "Driver details";
            this.btnDd.UseVisualStyleBackColor = false;
            this.btnDd.Click += new System.EventHandler(this.btnDd_Click);
            // 
            // btnVd
            // 
            this.btnVd.BackColor = System.Drawing.Color.Black;
            this.btnVd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVd.ForeColor = System.Drawing.Color.White;
            this.btnVd.Location = new System.Drawing.Point(32, 123);
            this.btnVd.Name = "btnVd";
            this.btnVd.Size = new System.Drawing.Size(261, 139);
            this.btnVd.TabIndex = 1;
            this.btnVd.Text = "Vehicle details";
            this.btnVd.UseVisualStyleBackColor = false;
            this.btnVd.Click += new System.EventHandler(this.btnVd_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(991, 542);
            this.Controls.Add(this.btnVd);
            this.Controls.Add(this.btnDd);
            this.Controls.Add(this.btnCd);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPd);
            this.Name = "Home";
            this.ShowIcon = false;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnCd;
        private System.Windows.Forms.Button btnDd;
        private System.Windows.Forms.Button btnVd;
    }
}