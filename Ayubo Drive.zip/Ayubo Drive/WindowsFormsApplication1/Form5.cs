﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Vehicle_details : Form
    {
        string vi, vt, vm, vn, ac, availability;
        int nos;
        public Vehicle_details()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnTgh_Click(object sender, EventArgs e)
        {
            Home h1 = new Home();
            this.Hide();
            h1.Show();
        }

        private void btnOkac_Click(object sender, EventArgs e)
        {
            if (chkYesac.Checked == true && chkNoac .Checked ==false )
            {
                txtAc.Text = "Yes";
            }
            else if (chkNoac.Checked == true && chkYesac.Checked == false )
            {
                txtAc.Text = "No";
            }
            else
            {
                MessageBox.Show("Choose Yes or No for ac");
            }

        }

        private void btnOkav_Click(object sender, EventArgs e)
        {
            if (chkYesav.Checked == true && chkNoav.Checked == false )
            {
                txtAvailability.Text = "Yes";
            }
            else if (chkNoav.Checked == true && chkYesav.Checked == false)
            {
                txtAvailability.Text = "No";
            }
            else
            {
                MessageBox.Show("Choose Yes or No for availability");
            }
        }

        private void Vehicle_details_Load(object sender, EventArgs e)
        {

        }

        private void txtNos_Leave(object sender, EventArgs e)
        {
            vi = txtVi.Text;
            vt = cmbVt.Text;
            vm = txtVm.Text;
            vn = txtVn.Text;
            ac = txtAc.Text;
            availability = txtAvailability.Text;
            nos = int.Parse (txtNos.Text);
        }
        private void clear()
        {
            txtVi.Clear();
            cmbVt.SelectedIndex = -1;
            chkNoac.Checked = false;
            chkYesac.Checked = false;
            chkNoav.Checked = false;
            chkYesav.Checked = false;
            txtVm.Clear();
            txtVn.Clear();
            txtAc.Clear();
            txtAvailability.Clear();
            txtNos.Clear();
            txtVi.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtVi.Clear();
            cmbVt.SelectedIndex = -1;
            chkNoac.Checked = false;
            chkYesac.Checked = false;
            chkNoav.Checked = false;
            chkYesav.Checked = false;
            txtVm.Clear();
            txtVn.Clear();
            txtAc.Clear();
            txtAvailability.Clear();
            txtNos.Clear();
            txtVi.Focus();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Vehicle values ('" + vi + "','" + vt + "','" + vm + "','" + vn + "','" 
                    + ac + "','" + availability + "','" + nos + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting..." + ex);
            }
            finally
            {
                con.Close();
            }
            
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                vi = txtVi.Text;
                vt = cmbVt.Text;
                vm = txtVm.Text;
                vn = txtVn.Text;
                ac = txtAc.Text;
                availability = txtAvailability.Text;
                nos = int.Parse(txtNos.Text);

                string update = "update Vehicle set vi='" + vi + "',vt='" + vt + "',vm='" + vm + "',vn='" + vn + "',ac='" 
                    + ac + "',availability='" + availability + "',nos='" + nos + "' where vi='" + vi + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                vi = txtVi.Text;

                string delete = "delete from Vehicle where vi='" + vi + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally
            {
                con.Close();
            }



        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                vi = txtVi.Text;

                string search = "select * from Vehicle where vi='" + vi + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    cmbVt.Text = r[1].ToString();
                    txtVm.Text = r[2].ToString();
                    txtVn.Text = r[3].ToString();
                    txtAc.Text = r[4].ToString();
                    txtAvailability.Text = r[5].ToString();
                    txtNos.Text = r[6].ToString();
                    if (r["ac"].ToString() == "Yes")
                    {
                        chkYesac .Checked  = true;
                    }
                    else
                    {
                        chkNoac .Checked  = true;
                    }
                    if (r["availability"].ToString() == "Yes")
                    {
                        chkYesav .Checked = true;
                    }
                    else
                    {
                        chkNoav .Checked = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void cmbVt_Leave(object sender, EventArgs e)
        {

        }
    }
}
