﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Long_hire_details : Form
    {
        string ci, di, vi,vt;
        int vr, exkr, sk, ek, pk, dr, pr, npr, tp, td, tk, exk, p;
        TimeSpan ts;
        DateTime sd, ed;
        public Long_hire_details()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");

        private void btnTgpd_Click(object sender, EventArgs e)
        {
            Package_details p1 = new Package_details();
            this.Hide();
            p1.Show();
        }

        private void Long_hire_details_Load(object sender, EventArgs e)
        {

        }

        private void txtNpr_Leave(object sender, EventArgs e)
        {
            ci = txtCi.Text;
            di = txtDi.Text;
            vi = txtVi.Text;
            vt = cmbVt.Text;
            vr = int.Parse(txtVr.Text);
            sd = dtpSd.Value.Date;
            ed = dtpEd.Value.Date;
            exkr = int.Parse(txtExkr.Text);
            sk = int.Parse(txtSk.Text);
            ek = int.Parse(txtEk.Text);
            pk = int.Parse(txtPk.Text);
            dr = int.Parse(txtDr.Text);
            pr = int.Parse(txtPr.Text);
            npr = int.Parse(txtNpr.Text);
        }

        private void btnTp_Click(object sender, EventArgs e)
        {
            ts = ed - sd;
            td = ts.Days;
            tk = ek - sk;
            exk = tk - pk;
            p = vr + dr + pr + (exk * exkr);
            if (td > 2)
            {
                tp = p + (td - 2) * npr;
            }
            else
            {
                tp = p;
            }
            txtTp.Text = tp.ToString();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            cmbVt.SelectedIndex = -1;
            txtVr.Clear();
            txtExkr.Clear();
            txtSk.Clear();
            txtEk.Clear();
            txtPk.Clear();
            txtDr.Clear();
            txtPr.Clear();
            txtNpr.Clear();
            txtTp.Clear();
        }
        private void clear()
        {

            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            cmbVt.SelectedIndex = -1;
            txtVr.Clear();
            txtExkr.Clear();
            txtSk.Clear();
            txtEk.Clear();
            txtPk.Clear();
            txtDr.Clear();
            txtPr.Clear();
            txtNpr.Clear();
            txtTp.Clear();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Lhire values ('" + ci + "','" + di + "','" + vi + "','" + vt + "','" + vr + "','" 
                    + sd + "','" + ed + "','" + exkr + "','" + sk + "','" + ek + "','" + pk + "','" 
                    + dr + "','" + pr + "','" + npr + "','" + tp + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting..." + ex);
            }
            finally
            {
                con.Close();
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                di = txtDi.Text;
                vi = txtVi.Text;
                vt = cmbVt.Text;
                vr = int.Parse(txtVr.Text);
                sd = dtpSd.Value.Date;
                ed = dtpEd.Value.Date;
                exkr = int.Parse(txtExkr.Text);
                sk = int.Parse(txtSk.Text);
                ek = int.Parse(txtEk.Text);
                pk = int.Parse(txtPk.Text);
                dr = int.Parse(txtDr.Text);
                pr = int.Parse(txtPr.Text);
                npr = int.Parse(txtNpr.Text);

                string update = "update Lhire set ci='" + ci + "',di='" + di + "',vi='" + vi + "',vt='" + vt + "',vr='" 
                    + vr + "',sd='" + sd + "',ed='" + ed + "',exkr='" + exkr + "',sk='" + sk + "',ek='" + ek + "',pk='" 
                    + pk + "',dr='" + dr + "',pr='" + pr + "',npr='" + npr + "',tp='" + tp + "' where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                string delete = "delete from Lhire where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                ci = txtCi.Text;
                string search = "select * from Lhire where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    txtDi.Text = r[1].ToString();
                    txtVi.Text = r[2].ToString();
                    cmbVt.Text = r[3].ToString();
                    txtVr.Text = r[4].ToString();
                    dtpSd.Text = r[5].ToString();
                    dtpEd.Text = r[6].ToString();
                    txtExkr.Text = r[7].ToString();
                    txtSk.Text = r[8].ToString();
                    txtEk.Text = r[9].ToString();
                    txtPk.Text = r[10].ToString();
                    txtDr.Text = r[11].ToString();
                    txtPr.Text = r[12].ToString();
                    txtNpr.Text = r[13].ToString();
                    txtTp.Text = r[14].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
