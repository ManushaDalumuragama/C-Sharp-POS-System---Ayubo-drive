﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Driver_details : Form
    {
        string di, fn, ln, address, nic;
        int lnn,pn;
        public Driver_details()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection
            (@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");


        private void btnTgh_Click(object sender, EventArgs e)
        {
            Home h1 = new Home();
            this.Hide();
            h1.Show();
        }

        private void Driver_details_Load(object sender, EventArgs e)
        {
        }

        private void txtPn_Leave(object sender, EventArgs e)
        {
            di = txtDi.Text;
            fn = txtFn.Text;
            ln = txtLn.Text;
            address = txtAddress.Text;
            nic = txtNic.Text;
            lnn = int.Parse(txtLnn.Text);
            pn = int.Parse(txtPn.Text);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDi.Clear();
            txtFn.Clear();
            txtLn.Clear();
            txtAddress.Clear();
            txtNic.Clear();
            txtLnn.Clear();
            txtPn.Clear();
            txtDi.Focus();
        }
        public void clear()
        {
            txtDi.Clear();
            txtFn.Clear();
            txtLn.Clear();
            txtAddress.Clear();
            txtNic.Clear();
            txtLnn.Clear();
            txtPn.Clear();
            txtDi.Focus();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Driver values ('" + di + "','" + fn + "','" + ln + "','" + address + "','" + nic + "','" + lnn + "','" + pn + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting..." + ex);
            }
            finally
            {
                con.Close();
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                di = txtDi.Text;
                fn = txtFn.Text;
                ln = txtLn.Text;
                address = txtAddress.Text;
                nic = txtNic.Text;
                lnn = int.Parse(txtLnn.Text);
                pn = int.Parse(txtPn.Text);

                string update = "update Driver set di='" + di + "',fn='" + fn + "',ln='" + ln + "',address='" + address + "',nic='" + nic + "',lnn='" 
                    + lnn + "',pn='" + pn + "' where di='" + di + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                di = txtDi.Text;

                string delete = "delete from Driver where di='" + di + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally
            {
                con.Close();
            }

           
        }
        void LoadGridView()
        {
          
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                di = txtDi.Text;
                string search = "select * from Driver where di='" + di + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    txtFn.Text = r[1].ToString();
                    txtLn.Text = r[2].ToString();
                    txtAddress.Text = r[3].ToString();
                    txtNic.Text = r[4].ToString();
                    txtLnn.Text = r[5].ToString();
                    txtPn.Text = r[6].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        
    }
}
