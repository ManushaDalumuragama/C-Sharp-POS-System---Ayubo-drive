﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Day_hire_details : Form
    {
        string ci, di, vi, pty;
        int pr, sk, ek, pk, exk, st, et, pt, ext, tk, tt, extr, exkr, dr, vr, tp;
        public Day_hire_details()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");
        private void btnTgpd_Click(object sender, EventArgs e)
        {
            Package_details p1 = new Package_details();
            this.Hide();
            p1.Show();
        }

        private void Day_hire_details_Load(object sender, EventArgs e)
        {

        }

        private void txtTp_Leave(object sender, EventArgs e)
        {
           
        }

        private void txtEtr_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtVr_Leave(object sender, EventArgs e)
        {
            ci = txtCi.Text;
            di = txtDi.Text;
            vi = txtVi.Text;
            pty = cmbPt.Text;
            pr = int.Parse(txtPr.Text);
            sk = int.Parse(txtSk.Text);
            ek = int.Parse(txtEk.Text);
            pk = int.Parse(txtPk.Text);
            st = int.Parse(txtSt.Text);
            et = int.Parse(txtEt.Text);
            pt = int.Parse(txtPt.Text);
            extr = int.Parse(txtExtr.Text);
            exkr = int.Parse(txtExkr.Text);
            dr = int.Parse(txtDr.Text);
            vr = int.Parse(txtVr.Text);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            cmbPt.SelectedIndex = -1;
            txtPr.Clear();
            txtSk.Clear();
            txtEk.Clear();
            txtPk.Clear();
            txtSt.Clear();
            txtEt.Clear();
            txtPt.Clear();
            txtExtr.Clear();
            txtExkr.Clear();
            txtDr.Clear();
            txtVr.Clear();
            txtTp.Clear();
        }
        private void clear()
        {
            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            cmbPt.SelectedIndex = -1;
            txtPr.Clear();
            txtSk.Clear();
            txtEk.Clear();
            txtPk.Clear();
            txtSt.Clear();
            txtEt.Clear();
            txtPt.Clear();
            txtExtr.Clear();
            txtExkr.Clear();
            txtDr.Clear();
            txtVr.Clear();
            txtTp.Clear();
        }

        private void btnTp_Click(object sender, EventArgs e)
        {
            tk = ek - sk;
            exk = tk - pk;
            tt = et - st;
            ext = tt - pt;
            tp = pr + dr + vr + (exk * exkr) + (ext * extr);
            txtTp.Text = tp.ToString();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Dhire values ('" + ci + "','" + di + "','" + vi + "','" + pty + "','" 
                    + pr + "','" + sk + "','" + ek + "','" + pk + "','" + st + "','" + et + "','" + pt + "','" 
                    + extr + "','" + exkr + "','" + dr + "','" + vr + "','" + tp + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                di = txtDi.Text;
                vi = txtVi.Text;
                pty = cmbPt.Text;
                pr = int.Parse(txtPr.Text);
                sk = int.Parse(txtSk.Text);
                ek = int.Parse(txtEk.Text);
                pk = int.Parse(txtPk.Text);
                st = int.Parse(txtSt.Text);
                et = int.Parse(txtEt.Text);
                pt = int.Parse(txtPt.Text);
                extr = int.Parse(txtExtr.Text);
                exkr = int.Parse(txtExkr.Text);
                dr = int.Parse(txtDr.Text);
                vr = int.Parse(txtVr.Text);

                string update = "update Dhire set ci='" + ci + "',di='" + di + "',vi='" + vi + "',pty='" + pty + "',pr='" 
                    + pr + "',sk='" + sk + "',ek='" + ek + "',pk='" + pk + "',st='" + st + "',et='" + et + "',pt='" 
                    + pt + "',extr='" + extr + "',exkr='" + exkr + "',dr='" + dr + "',vr='" + vr + "',tp='" 
                    + tp + "' where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..."+ex );
            }
            finally 
            {
                con.Close();
            }


            }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                string delete = "delete from Dhire where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally 
            {
                con.Close();
            }
        

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                ci = txtCi.Text;
                string search = "select * from Dhire where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    txtDi.Text = r[1].ToString();
                    txtVi.Text = r[2].ToString();
                    cmbPt.Text = r[3].ToString();
                    txtPr.Text = r[4].ToString();
                    txtSk.Text = r[5].ToString();
                    txtEk.Text = r[6].ToString();
                    txtPk.Text = r[7].ToString();
                    txtSt.Text = r[8].ToString();
                    txtEt.Text = r[9].ToString();
                    txtPt.Text = r[10].ToString();
                    txtExtr.Text = r[11].ToString();
                    txtExkr.Text = r[12].ToString();
                    txtDr.Text = r[13].ToString();
                    txtVr.Text = r[14].ToString();
                    txtTp.Text = r[15].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

    }
}
