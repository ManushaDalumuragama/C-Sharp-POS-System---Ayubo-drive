﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Login : Form
    {
        string un, pw;
        Home h1 = new Home ();
        public Login()
        {
            InitializeComponent();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (un == "ayubodrive" && pw == "ayubo123")
            {
                MessageBox.Show("Welcome!");
                Home h1 = new Home();
                this.Hide();
                h1.Show();
            }
            else
            {
               MessageBox.Show("User name or Password is incorrect");
            }
            

        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            un = txtUn.Text;
            pw = txtPw.Text;
        }
        

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
