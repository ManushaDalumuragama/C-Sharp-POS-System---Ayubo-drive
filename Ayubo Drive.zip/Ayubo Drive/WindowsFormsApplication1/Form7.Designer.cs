﻿namespace WindowsFormsApplication1
{
    partial class Package_details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Package_details));
            this.label1 = new System.Windows.Forms.Label();
            this.btnRd = new System.Windows.Forms.Button();
            this.btnDhd = new System.Windows.Forms.Button();
            this.btnLhd = new System.Windows.Forms.Button();
            this.btnTgh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Stencil Std", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(409, 53);
            this.label1.TabIndex = 24;
            this.label1.Text = "Package details";
            // 
            // btnRd
            // 
            this.btnRd.BackColor = System.Drawing.Color.Black;
            this.btnRd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRd.ForeColor = System.Drawing.Color.White;
            this.btnRd.Location = new System.Drawing.Point(48, 90);
            this.btnRd.Name = "btnRd";
            this.btnRd.Size = new System.Drawing.Size(244, 129);
            this.btnRd.TabIndex = 1;
            this.btnRd.Text = "Rent details";
            this.btnRd.UseVisualStyleBackColor = false;
            this.btnRd.Click += new System.EventHandler(this.btnRd_Click);
            // 
            // btnDhd
            // 
            this.btnDhd.BackColor = System.Drawing.Color.Black;
            this.btnDhd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDhd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDhd.ForeColor = System.Drawing.Color.White;
            this.btnDhd.Location = new System.Drawing.Point(334, 90);
            this.btnDhd.Name = "btnDhd";
            this.btnDhd.Size = new System.Drawing.Size(244, 122);
            this.btnDhd.TabIndex = 2;
            this.btnDhd.Text = "Day hire details";
            this.btnDhd.UseVisualStyleBackColor = false;
            this.btnDhd.Click += new System.EventHandler(this.btnDhd_Click);
            // 
            // btnLhd
            // 
            this.btnLhd.BackColor = System.Drawing.Color.Black;
            this.btnLhd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLhd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLhd.ForeColor = System.Drawing.Color.White;
            this.btnLhd.Location = new System.Drawing.Point(48, 254);
            this.btnLhd.Name = "btnLhd";
            this.btnLhd.Size = new System.Drawing.Size(244, 132);
            this.btnLhd.TabIndex = 3;
            this.btnLhd.Text = "Long hire details";
            this.btnLhd.UseVisualStyleBackColor = false;
            this.btnLhd.Click += new System.EventHandler(this.btnLhd_Click);
            // 
            // btnTgh
            // 
            this.btnTgh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTgh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTgh.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTgh.Location = new System.Drawing.Point(12, 491);
            this.btnTgh.Name = "btnTgh";
            this.btnTgh.Size = new System.Drawing.Size(154, 40);
            this.btnTgh.TabIndex = 4;
            this.btnTgh.Text = "To go home";
            this.btnTgh.UseVisualStyleBackColor = false;
            this.btnTgh.Click += new System.EventHandler(this.btnTgh_Click);
            // 
            // Package_details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(992, 543);
            this.Controls.Add(this.btnTgh);
            this.Controls.Add(this.btnRd);
            this.Controls.Add(this.btnDhd);
            this.Controls.Add(this.btnLhd);
            this.Controls.Add(this.label1);
            this.Name = "Package_details";
            this.ShowIcon = false;
            this.Text = "Package details";
            this.Load += new System.EventHandler(this.Package_details_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRd;
        private System.Windows.Forms.Button btnDhd;
        private System.Windows.Forms.Button btnLhd;
        private System.Windows.Forms.Button btnTgh;
    }
}