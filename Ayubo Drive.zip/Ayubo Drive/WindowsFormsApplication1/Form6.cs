﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Customer_details : Form
    {
        string ci, fn, ln, nic;
        int pn;
        public Customer_details()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");

        private void btnTgh_Click(object sender, EventArgs e)
        {
            Home h1 = new Home();
            this.Hide();
            h1.Show();
        }

        private void Customer_details_Load(object sender, EventArgs e)
        {

        }

        private void txtPn_Leave(object sender, EventArgs e)
        {
            ci = txtCi.Text;
            fn = txtFn.Text;
            ln = txtLn.Text;
            nic = txtNic.Text;
            pn = int.Parse(txtPn.Text);
        }
        private void clear()
        {
            txtCi.Clear();
            txtFn.Clear();
            txtLn.Clear();
            txtNic.Clear();
            txtPn.Clear();
            txtCi.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCi.Clear();
            txtFn.Clear();
            txtLn.Clear();
            txtNic.Clear();
            txtPn.Clear();
            txtCi.Focus();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Customer values ('" + ci + "','" + fn + "','" + ln + "','" + nic + "','" + pn + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                fn = txtFn.Text;
                ln = txtLn.Text;
                nic = txtNic.Text;
                pn = int.Parse(txtPn.Text);

                string update = "update Customer set ci='" + ci + "',fn='" + fn + "',ln='" + ln + "',nic='" 
                    + nic + "',pn='" + pn + "' where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                string delete = "delete from Customer where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                ci = txtCi.Text;
                string search = "select * from Customer where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    txtFn.Text = r[1].ToString();
                    txtLn.Text = r[2].ToString();
                    txtNic.Text = r[3].ToString();
                    txtPn.Text = r[4].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }

        }
    }
}
