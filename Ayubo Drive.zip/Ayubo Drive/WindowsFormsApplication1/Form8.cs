﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data .SqlClient ;

namespace WindowsFormsApplication1
{
    public partial class Rent_details : Form
    {
        int td,m, w, d, mlr, wlr, dlr, vr, p, tp, dr;
        string ci, di, vi, driver;
        TimeSpan ts;
        DateTime sd, ed;


        public Rent_details()
        {
            InitializeComponent();
        }

        private void chkWith_CheckedChanged(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Aayubo_Drive.mdf;Integrated Security=True");

        private void btnTgh_Click(object sender, EventArgs e)
        {
            Package_details p1 = new Package_details();
            this.Hide ();
            p1 .Show ();
        }

        private void Rent_details_Load(object sender, EventArgs e)
        {

        }

        private void txtDr_Leave(object sender, EventArgs e)
        {
            ci = txtCi.Text;
            di = txtDi.Text;
            vi = txtVi.Text;
            mlr = int.Parse(txtMlr.Text);
            wlr = int.Parse(txtWlr.Text);
            dlr = int.Parse(txtDlr.Text);
            vr = int.Parse(txtVr.Text);
            driver = txtDriver.Text;
            dr = int.Parse(txtDr.Text);
            sd = dtpSd.Value.Date;
            ed = dtpEd.Value.Date;
        }

        private void txtTp_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            txtMlr.Clear();
            txtWlr.Clear();
            txtDlr.Clear();
            txtVr.Clear();
            txtDriver.Clear();
            txtDr.Clear();
            txtTp.Clear();
            chkWith.Checked = false;
            chkWithout.Checked = false;
            txtCi.Focus();

        }
        private void clear()
        {
            txtCi.Clear();
            txtDi.Clear();
            txtVi.Clear();
            txtMlr.Clear();
            txtWlr.Clear();
            txtDlr.Clear();
            txtVr.Clear();
            txtDriver.Clear();
            txtDr.Clear();
            txtTp.Clear();
            chkWith.Checked = false;
            chkWithout.Checked = false;
            txtCi.Focus();
        }


        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                string insert = "insert into Rent values ('" + ci + "','" + di + "','" + vi + "','" + sd + "','" + ed + "','" 
                    + mlr + "','" + wlr + "','" + dlr + "','" + vr + "','" + driver + "','" + dr + "','" + tp + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Inserted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while inserting..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnTp_Click(object sender, EventArgs e)
        {
            ts = ed - sd;
            td = ts.Days;
            m = td / 30;
            w = (td % 30) / 7;
            d = (td % 30) % 7;
            p = (m * mlr) + (w * wlr) + (d * dlr) + vr;
            if (chkWithout.Checked == true && chkWith.Checked == false)
            {
                tp = p;
            }
            else if (chkWith.Checked == true && chkWithout.Checked == false)
            {
                tp = p + dr;
            }
            else
            {
                MessageBox.Show("Choose With or Without for driver");
            }
            txtTp.Text = tp.ToString();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (chkWith.Checked == true && chkWithout.Checked == false)
            {
                txtDriver.Text = "With";
            }
            else if (chkWith .Checked ==false && chkWithout .Checked ==true )
            {
                txtDriver.Text = "Without";
            }
            else 
            {
                MessageBox.Show("Choose With or Without for driver");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                di = txtDi.Text;
                vi = txtVi.Text;
                mlr = int.Parse(txtMlr.Text);
                wlr = int.Parse(txtWlr.Text);
                dlr = int.Parse(txtDlr.Text);
                vr = int.Parse(txtVr.Text);
                driver = txtDriver.Text;
                dr = int.Parse(txtDr.Text);
                sd = dtpSd.Value.Date;
                ed = dtpEd.Value.Date;

                string update = "update Rent set ci='" + ci + "',di='" + di + "',vi='" + vi + "',sd='" + sd + "',ed='" + ed + "',mlr='" 
                    + mlr + "',wlr='" + wlr + "',dlr='" + dlr + "',vr='" + vr + "',driver='" + driver + "',dr='" + dr 
                    + "',tp='" + tp + "' where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                ci = txtCi.Text;
                string delete = "delete from Rent where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted successfully");
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting..." + ex);
            }
            finally
            {
                con.Close();
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
                ci = txtCi.Text;
                string search = "select *from Rent where ci='" + ci + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    txtDi.Text = r[1].ToString();
                    txtVi.Text = r[2].ToString();
                    dtpSd.Text = r[3].ToString();
                    dtpEd.Text = r[4].ToString();
                    txtMlr.Text = r[5].ToString();
                    txtWlr.Text = r[6].ToString();
                    txtDlr.Text = r[7].ToString();
                    txtVr.Text = r[8].ToString();
                    txtDriver.Text = r[9].ToString();
                    txtDr.Text = r[10].ToString();
                    txtTp.Text = r[11].ToString();
                    if (r["driver"].ToString() == "With")
                    {
                        chkWith .Checked  = true;
                    }
                    else
                    {
                        chkWithout .Checked  = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching..." + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void txtTp_Leave(object sender, EventArgs e)
        {
           
        }
    }
}
