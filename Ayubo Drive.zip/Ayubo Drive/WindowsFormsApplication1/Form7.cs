﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Package_details : Form
    {
        public Package_details()
        {
            InitializeComponent();
        }

        private void btnTgh_Click(object sender, EventArgs e)
        {
            Home h1 = new Home();
            this.Hide();
            h1.Show();
        }

        private void btnRd_Click(object sender, EventArgs e)
        {
            Rent_details r1 = new Rent_details();
            this.Hide();
            r1.Show();
        }

        private void btnDhd_Click(object sender, EventArgs e)
        {
            Day_hire_details d1 = new Day_hire_details();
            this.Hide();
            d1.Show();
        }

        private void btnLhd_Click(object sender, EventArgs e)
        {
            Long_hire_details l1 = new Long_hire_details();
            this.Hide();
            l1.Show();
        }

        private void Package_details_Load(object sender, EventArgs e)
        {

        }
    }
}
